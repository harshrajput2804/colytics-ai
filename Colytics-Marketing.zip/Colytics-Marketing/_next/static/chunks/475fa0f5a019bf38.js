(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 35451, (e, t, r) => { var n = { 229: function (e) { var t, r, n, o = e.exports = {}; function u() { throw Error("setTimeout has not been defined"); } function i() { throw Error("clearTimeout has not been defined"); } try {
            t = "function" == typeof setTimeout ? setTimeout : u;
        }
        catch (e) {
            t = u;
        } try {
            r = "function" == typeof clearTimeout ? clearTimeout : i;
        }
        catch (e) {
            r = i;
        } function s(e) { if (t === setTimeout)
            return setTimeout(e, 0); if ((t === u || !t) && setTimeout)
            return t = setTimeout, setTimeout(e, 0); try {
            return t(e, 0);
        }
        catch (r) {
            try {
                return t.call(null, e, 0);
            }
            catch (r) {
                return t.call(this, e, 0);
            }
        } } var c = [], l = !1, a = -1; function f() { l && n && (l = !1, n.length ? c = n.concat(c) : a = -1, c.length && p()); } function p() { if (!l) {
            var e = s(f);
            l = !0;
            for (var t = c.length; t;) {
                for (n = c, c = []; ++a < t;)
                    n && n[a].run();
                a = -1, t = c.length;
            }
            n = null, l = !1, function (e) { if (r === clearTimeout)
                return clearTimeout(e); if ((r === i || !r) && clearTimeout)
                return r = clearTimeout, clearTimeout(e); try {
                r(e);
            }
            catch (t) {
                try {
                    return r.call(null, e);
                }
                catch (t) {
                    return r.call(this, e);
                }
            } }(e);
        } } function d(e, t) { this.fun = e, this.array = t; } function y() { } o.nextTick = function (e) { var t = Array(arguments.length - 1); if (arguments.length > 1)
            for (var r = 1; r < arguments.length; r++)
                t[r - 1] = arguments[r]; c.push(new d(e, t)), 1 !== c.length || l || s(p); }, d.prototype.run = function () { this.fun.apply(null, this.array); }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = y, o.addListener = y, o.once = y, o.off = y, o.removeListener = y, o.removeAllListeners = y, o.emit = y, o.prependListener = y, o.prependOnceListener = y, o.listeners = function (e) { return []; }, o.binding = function (e) { throw Error("process.binding is not supported"); }, o.cwd = function () { return "/"; }, o.chdir = function (e) { throw Error("process.chdir is not supported"); }, o.umask = function () { return 0; }; } }, o = {}; function u(e) { var t = o[e]; if (void 0 !== t)
        return t.exports; var r = o[e] = { exports: {} }, i = !0; try {
        n[e](r, r.exports, u), i = !1;
    }
    finally {
        i && delete o[e];
    } return r.exports; } u.ab = "/ROOT/node_modules/next/dist/compiled/process/", t.exports = u(229); }, 47167, (e, t, r) => {
        "use strict";
        var n, o;
        t.exports = (null == (n = e.g.process) ? void 0 : n.env) && "object" == typeof (null == (o = e.g.process) ? void 0 : o.env) ? e.g.process : e.r(35451);
    }, 45689, (e, t, r) => {
        "use strict";
        var n = Symbol.for("react.transitional.element");
        function o(e, t, r) { var o = null; if (void 0 !== r && (o = "" + r), void 0 !== t.key && (o = "" + t.key), "key" in t)
            for (var u in r = {}, t)
                "key" !== u && (r[u] = t[u]);
        else
            r = t; return { $$typeof: n, type: e, key: o, ref: void 0 !== (t = r.ref) ? t : null, props: r }; }
        r.Fragment = Symbol.for("react.fragment"), r.jsx = o, r.jsxs = o;
    }, 43476, (e, t, r) => {
        "use strict";
        t.exports = e.r(45689);
    }, 90317, (e, t, r) => {
        "use strict";
        Object.defineProperty(r, "__esModule", { value: !0 });
        var n = { bindSnapshot: function () { return l; }, createAsyncLocalStorage: function () { return c; }, createSnapshot: function () { return a; } };
        for (var o in n)
            Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
        let u = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", { value: "E504", enumerable: !1, configurable: !0 });
        class i {
            disable() { throw u; }
            getStore() { }
            run() { throw u; }
            exit() { throw u; }
            enterWith() { throw u; }
            static bind(e) { return e; }
        }
        let s = "undefined" != typeof globalThis && globalThis.AsyncLocalStorage;
        function c() { return s ? new s : new i; }
        function l(e) { return s ? s.bind(e) : i.bind(e); }
        function a() { return s ? s.snapshot() : function (e, ...t) { return e(...t); }; }
    }, 42344, (e, t, r) => {
        "use strict";
        Object.defineProperty(r, "__esModule", { value: !0 }), Object.defineProperty(r, "workAsyncStorageInstance", { enumerable: !0, get: function () { return n; } });
        let n = (0, e.r(90317).createAsyncLocalStorage)();
    }, 63599, (e, t, r) => {
        "use strict";
        Object.defineProperty(r, "__esModule", { value: !0 }), Object.defineProperty(r, "workAsyncStorage", { enumerable: !0, get: function () { return n.workAsyncStorageInstance; } });
        let n = e.r(42344);
    }, 12354, (e, t, r) => {
        "use strict";
        Object.defineProperty(r, "__esModule", { value: !0 }), Object.defineProperty(r, "HandleISRError", { enumerable: !0, get: function () { return o; } });
        let n = "undefined" == typeof window ? e.r(63599).workAsyncStorage : void 0;
        function o({ error: e }) { if (n) {
            let t = n.getStore();
            if (t?.isStaticGeneration)
                throw e && console.error(e), e;
        } return null; }
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", { value: !0 }), Object.assign(r.default, r), t.exports = r.default);
    }, 50740, (e, t, r) => {
        "use strict";
        var n = e.i(47167), o = Symbol.for("react.transitional.element"), u = Symbol.for("react.portal"), i = Symbol.for("react.fragment"), s = Symbol.for("react.strict_mode"), c = Symbol.for("react.profiler"), l = Symbol.for("react.consumer"), a = Symbol.for("react.context"), f = Symbol.for("react.forward_ref"), p = Symbol.for("react.suspense"), d = Symbol.for("react.memo"), y = Symbol.for("react.lazy"), h = Symbol.for("react.activity"), v = Symbol.for("react.view_transition"), b = Symbol.iterator, m = { isMounted: function () { return !1; }, enqueueForceUpdate: function () { }, enqueueReplaceState: function () { }, enqueueSetState: function () { } }, _ = Object.assign, g = {};
        function S(e, t, r) { this.props = e, this.context = t, this.refs = g, this.updater = r || m; }
        function j() { }
        function w(e, t, r) { this.props = e, this.context = t, this.refs = g, this.updater = r || m; }
        S.prototype.isReactComponent = {}, S.prototype.setState = function (e, t) { if ("object" != typeof e && "function" != typeof e && null != e)
            throw Error("takes an object of state variables to update or a function which returns an object of state variables."); this.updater.enqueueSetState(this, e, t, "setState"); }, S.prototype.forceUpdate = function (e) { this.updater.enqueueForceUpdate(this, e, "forceUpdate"); }, j.prototype = S.prototype;
        var E = w.prototype = new j;
        E.constructor = w, _(E, S.prototype), E.isPureReactComponent = !0;
        var x = Array.isArray;
        function T() { }
        var O = { H: null, A: null, T: null, S: null }, k = Object.prototype.hasOwnProperty;
        function R(e, t, r) { var n = r.ref; return { $$typeof: o, type: e, key: t, ref: void 0 !== n ? n : null, props: r }; }
        function A(e) { return "object" == typeof e && null !== e && e.$$typeof === o; }
        var H = /\/+/g;
        function C(e, t) { var r, n; return "object" == typeof e && null !== e && null != e.key ? (r = "" + e.key, n = { "=": "=0", ":": "=2" }, "$" + r.replace(/[=:]/g, function (e) { return n[e]; })) : t.toString(36); }
        function P(e, t, r) { if (null == e)
            return e; var n = [], i = 0; return !function e(t, r, n, i, s) { var c, l, a, f = typeof t; ("undefined" === f || "boolean" === f) && (t = null); var p = !1; if (null === t)
            p = !0;
        else
            switch (f) {
                case "bigint":
                case "string":
                case "number":
                    p = !0;
                    break;
                case "object": switch (t.$$typeof) {
                    case o:
                    case u:
                        p = !0;
                        break;
                    case y: return e((p = t._init)(t._payload), r, n, i, s);
                }
            } if (p)
            return s = s(t), p = "" === i ? "." + C(t, 0) : i, x(s) ? (n = "", null != p && (n = p.replace(H, "$&/") + "/"), e(s, r, n, "", function (e) { return e; })) : null != s && (A(s) && (c = s, l = n + (null == s.key || t && t.key === s.key ? "" : ("" + s.key).replace(H, "$&/") + "/") + p, s = R(c.type, l, c.props)), r.push(s)), 1; p = 0; var d = "" === i ? "." : i + ":"; if (x(t))
            for (var h = 0; h < t.length; h++)
                f = d + C(i = t[h], h), p += e(i, r, n, f, s);
        else if ("function" == typeof (h = null === (a = t) || "object" != typeof a ? null : "function" == typeof (a = b && a[b] || a["@@iterator"]) ? a : null))
            for (t = h.call(t), h = 0; !(i = t.next()).done;)
                f = d + C(i = i.value, h++), p += e(i, r, n, f, s);
        else if ("object" === f) {
            if ("function" == typeof t.then)
                return e(function (e) { switch (e.status) {
                    case "fulfilled": return e.value;
                    case "rejected": throw e.reason;
                    default: switch ("string" == typeof e.status ? e.then(T, T) : (e.status = "pending", e.then(function (t) { "pending" === e.status && (e.status = "fulfilled", e.value = t); }, function (t) { "pending" === e.status && (e.status = "rejected", e.reason = t); })), e.status) {
                        case "fulfilled": return e.value;
                        case "rejected": throw e.reason;
                    }
                } throw e; }(t), r, n, i, s);
            throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === (r = String(t)) ? "object with keys {" + Object.keys(t).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead.");
        } return p; }(e, n, "", "", function (e) { return t.call(r, e, i++); }), n; }
        function $(e) { if (-1 === e._status) {
            var t = e._result;
            (t = t()).then(function (t) { (0 === e._status || -1 === e._status) && (e._status = 1, e._result = t); }, function (t) { (0 === e._status || -1 === e._status) && (e._status = 2, e._result = t); }), -1 === e._status && (e._status = 0, e._result = t);
        } if (1 === e._status)
            return e._result.default; throw e._result; }
        var I = "function" == typeof reportError ? reportError : function (e) { if ("object" == typeof window && "function" == typeof window.ErrorEvent) {
            var t = new window.ErrorEvent("error", { bubbles: !0, cancelable: !0, message: "object" == typeof e && null !== e && "string" == typeof e.message ? String(e.message) : String(e), error: e });
            if (!window.dispatchEvent(t))
                return;
        }
        else if ("object" == typeof n.default && "function" == typeof n.default.emit)
            return void n.default.emit("uncaughtException", e); console.error(e); };
        function M(e) { var t = O.T, r = {}; r.types = null !== t ? t.types : null, O.T = r; try {
            var n = e(), o = O.S;
            null !== o && o(r, n), "object" == typeof n && null !== n && "function" == typeof n.then && n.then(T, I);
        }
        catch (e) {
            I(e);
        }
        finally {
            null !== t && null !== r.types && (t.types = r.types), O.T = t;
        } }
        function L(e) { var t = O.T; if (null !== t) {
            var r = t.types;
            null === r ? t.types = [e] : -1 === r.indexOf(e) && r.push(e);
        }
        else
            M(L.bind(null, e)); }
        r.Activity = h, r.Children = { map: P, forEach: function (e, t, r) { P(e, function () { t.apply(this, arguments); }, r); }, count: function (e) { var t = 0; return P(e, function () { t++; }), t; }, toArray: function (e) { return P(e, function (e) { return e; }) || []; }, only: function (e) { if (!A(e))
                throw Error("React.Children.only expected to receive a single React element child."); return e; } }, r.Component = S, r.Fragment = i, r.Profiler = c, r.PureComponent = w, r.StrictMode = s, r.Suspense = p, r.ViewTransition = v, r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = O, r.__COMPILER_RUNTIME = { __proto__: null, c: function (e) { return O.H.useMemoCache(e); } }, r.addTransitionType = L, r.cache = function (e) { return function () { return e.apply(null, arguments); }; }, r.cacheSignal = function () { return null; }, r.cloneElement = function (e, t, r) { if (null == e)
            throw Error("The argument must be a React element, but you passed " + e + "."); var n = _({}, e.props), o = e.key; if (null != t)
            for (u in void 0 !== t.key && (o = "" + t.key), t)
                k.call(t, u) && "key" !== u && "__self" !== u && "__source" !== u && ("ref" !== u || void 0 !== t.ref) && (n[u] = t[u]); var u = arguments.length - 2; if (1 === u)
            n.children = r;
        else if (1 < u) {
            for (var i = Array(u), s = 0; s < u; s++)
                i[s] = arguments[s + 2];
            n.children = i;
        } return R(e.type, o, n); }, r.createContext = function (e) { return (e = { $$typeof: a, _currentValue: e, _currentValue2: e, _threadCount: 0, Provider: null, Consumer: null }).Provider = e, e.Consumer = { $$typeof: l, _context: e }, e; }, r.createElement = function (e, t, r) { var n, o = {}, u = null; if (null != t)
            for (n in void 0 !== t.key && (u = "" + t.key), t)
                k.call(t, n) && "key" !== n && "__self" !== n && "__source" !== n && (o[n] = t[n]); var i = arguments.length - 2; if (1 === i)
            o.children = r;
        else if (1 < i) {
            for (var s = Array(i), c = 0; c < i; c++)
                s[c] = arguments[c + 2];
            o.children = s;
        } if (e && e.defaultProps)
            for (n in i = e.defaultProps)
                void 0 === o[n] && (o[n] = i[n]); return R(e, u, o); }, r.createRef = function () { return { current: null }; }, r.forwardRef = function (e) { return { $$typeof: f, render: e }; }, r.isValidElement = A, r.lazy = function (e) { return { $$typeof: y, _payload: { _status: -1, _result: e }, _init: $ }; }, r.memo = function (e, t) { return { $$typeof: d, type: e, compare: void 0 === t ? null : t }; }, r.startTransition = M, r.unstable_useCacheRefresh = function () { return O.H.useCacheRefresh(); }, r.use = function (e) { return O.H.use(e); }, r.useActionState = function (e, t, r) { return O.H.useActionState(e, t, r); }, r.useCallback = function (e, t) { return O.H.useCallback(e, t); }, r.useContext = function (e) { return O.H.useContext(e); }, r.useDebugValue = function () { }, r.useDeferredValue = function (e, t) { return O.H.useDeferredValue(e, t); }, r.useEffect = function (e, t) { return O.H.useEffect(e, t); }, r.useEffectEvent = function (e) { return O.H.useEffectEvent(e); }, r.useId = function () { return O.H.useId(); }, r.useImperativeHandle = function (e, t, r) { return O.H.useImperativeHandle(e, t, r); }, r.useInsertionEffect = function (e, t) { return O.H.useInsertionEffect(e, t); }, r.useLayoutEffect = function (e, t) { return O.H.useLayoutEffect(e, t); }, r.useMemo = function (e, t) { return O.H.useMemo(e, t); }, r.useOptimistic = function (e, t) { return O.H.useOptimistic(e, t); }, r.useReducer = function (e, t, r) { return O.H.useReducer(e, t, r); }, r.useRef = function (e) { return O.H.useRef(e); }, r.useState = function (e) { return O.H.useState(e); }, r.useSyncExternalStore = function (e, t, r) { return O.H.useSyncExternalStore(e, t, r); }, r.useTransition = function () { return O.H.useTransition(); }, r.version = "19.3.0-canary-52684925-20251110";
    }, 71645, (e, t, r) => {
        "use strict";
        t.exports = e.r(50740);
    }, 68027, (e, t, r) => {
        "use strict";
        Object.defineProperty(r, "__esModule", { value: !0 }), Object.defineProperty(r, "default", { enumerable: !0, get: function () { return s; } });
        let n = e.r(43476), o = e.r(12354), u = { fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"', height: "100vh", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }, i = { fontSize: "14px", fontWeight: 400, lineHeight: "28px", margin: "0 8px" }, s = function ({ error: e }) { let t = e?.digest; return (0, n.jsxs)("html", { id: "__next_error__", children: [(0, n.jsx)("head", {}), (0, n.jsxs)("body", { children: [(0, n.jsx)(o.HandleISRError, { error: e }), (0, n.jsx)("div", { style: u, children: (0, n.jsxs)("div", { children: [(0, n.jsxs)("h2", { style: i, children: ["Application error: a ", t ? "server" : "client", "-side exception has occurred while loading ", window.location.hostname, " (see the", " ", t ? "server logs" : "browser console", " for more information)."] }), t ? (0, n.jsx)("p", { style: i, children: `Digest: ${t}` }) : null] }) })] })] }); };
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", { value: !0 }), Object.assign(r.default, r), t.exports = r.default);
    }, 42732, (e, t, r) => {
        "use strict";
        Object.defineProperty(r, "__esModule", { value: !0 }), Object.defineProperty(r, "HeadManagerContext", { enumerable: !0, get: function () { return n; } });
        let n = e.r(55682)._(e.r(71645)).default.createContext({});
    }]);
